export const IncAction=(inp)=>async dispatch=>{
    dispatch({type:'increment',payload:inp})
}


export const DeccAction=(inp)=>async dispatch=>{
    dispatch({type:'decrement',payload:inp})
}