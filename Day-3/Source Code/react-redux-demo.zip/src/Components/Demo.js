import React from 'react'
import {connect} from 'react-redux'
import {IncAction,DeccAction} from './Actions'

function Demo(props) {
  return (
    <div>
        <h1>Count:{props.counter}</h1>
        <button onClick={()=>props.DeccAction(10)}>Decrement</button>
        <button onClick={()=>props.IncAction(10)}>Increment</button>
    </div>
  )
}
const mapStateToProps=(state)=>
({
    counter:state
})

export default connect(mapStateToProps,{IncAction,DeccAction})(Demo)