import logo from './logo.svg';
import './App.css';
import Demo from './Components/Demo';
import { Provider } from 'react-redux';
import Store from './Components/Store';

function App() {
  return (
    <div className="App">
      <Provider store={Store}>
          <Demo/>
      </Provider>
        
    </div>
  );
}

export default App;
