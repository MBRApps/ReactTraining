import { createSlice } from "@reduxjs/toolkit";

const initialState={
    Cart:[]
}
const CartReducer=createSlice({
    name:'CartReducer',
    initialState,
    reducers:{
        addtocart:(state,action)=>{
            state.Cart.push(action.payload)

            const priceArr=state.Cart.map(x=>x.price)
            state.total=priceArr.reduce((a,b)=>a+b)

            state.totalCount=state.Cart.length;
        },
        removefromcart:(state,action)=>{
            const index=state.Cart.findIndex(x=>x.id==action.payload.id)
            if(index>-1)
            {
                state.Cart.splice(index,1)
            }

            if(state.Cart.length!=0)
            {
                const priceArr=state.Cart.map(x=>x.price)
                state.total=priceArr.reduce((a,b)=>a+b)
            }
            else{
                
                state.total=0
            }
            state.totalCount=state.Cart.length;
        }
    }
})

export const{addtocart,removefromcart}=CartReducer.actions
export default CartReducer.reducer