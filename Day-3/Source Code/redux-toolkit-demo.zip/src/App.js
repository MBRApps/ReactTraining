import logo from './logo.svg';
import './App.css';
import Demo from './Components/Demo';
import Navbar from './Components/Navbar';
import { Provider } from 'react-redux';
import { Store } from './Redux/Store';

function App() {
  return (
    <div className="App">
      <Provider store={Store}>
          <Navbar/>
          <Demo/>
      </Provider>
      
    </div>
  );
}

export default App;
