import React from 'react'
import {useSelector} from 'react-redux'

function Navbar() {
    const cartTotal=useSelector((state)=>state.CartReducer.total)
    const cartCount=useSelector((state)=>state.CartReducer.totalCount)
  return (
    <div>
        <nav className='navbar navbar-dark bg-dark'>
            <div className='d-inline p-3 navbar-nav mx-auto'>
                <span className='btn btn-primary'>
                    Cart Items:{cartCount}
                </span>
                &nbsp;
                <span className='btn btn-primary'>
                    Cart Total:{cartTotal}
                </span>
            </div>
        </nav>
    </div>
  )
}

export default Navbar