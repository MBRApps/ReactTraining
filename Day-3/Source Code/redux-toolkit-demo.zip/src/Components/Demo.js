import React from 'react'
import ProductsData from '../Data/ProductsData.json'
import {useDispatch} from 'react-redux'
import { addtocart, removefromcart } from '../Redux/CartReducer'

const Demo=()=> {
    const dispatch=useDispatch()
  return (
    <div className='container mt-3'>
        <div className='row'>
        {
            ProductsData.Products.map((x,i)=>
                <div className='col'>
                    <div className='card'>
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR77YOFcZAnjtWBfdrgrxKYn6NJiYsFpXbqvA&usqp=CAU" height={100} width={75}/>
                        <p className='card-title'>{x.name}|{x.price}</p>
                        <div className='card-body mt-2'>
                        <button className='btn btn-primary'
                         onClick={()=>dispatch(addtocart({id:x.id,name:x.name,price:x.price}))}>Add to Cart</button>
                        &nbsp;
                        <button className='btn btn-primary' 
                         onClick={()=>dispatch(removefromcart({id:x.id,name:x.name,price:x.price}))}>Remove From Cart</button>
                    </div>
                    </div>
                   
                </div>
            )
        }
        </div>
    </div>
  )
}

export default Demo