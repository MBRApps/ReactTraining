import React, { Component } from 'react'
import MemoComponentDemo from './MemoComponentDemo'

export class NormalComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'steve'
      }
    }
    componentDidMount()
    {
        setInterval(()=>{
            this.setState({name:'steve'})
        },2000)
    }
  render() {
    console.log("------------Normal Component-------------------")
    return (
      <div>
        RegularComponent
        <MemoComponentDemo name={this.state.name}/>
       </div>
    )
  }
}

export default NormalComponent