import React from 'react'

function MemoComponentDemo(props) {
    console.log("------------Child Component-------------------")
  return (
    <div>
        MemoComponentDemo
        <h1>{props.name}</h1>
    </div>
  )
}

export default React.memo(MemoComponentDemo)