import React, { Component } from 'react'

export class Child extends Component {
  render() {
    return (
      <div>
        <button onClick={this.props.handler}>increment</button>
      </div>
    )
  }
}

export default Child