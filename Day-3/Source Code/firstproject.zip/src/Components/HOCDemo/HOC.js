import React from 'react'
import { render } from 'react-dom'

const HOC=(Component)=> {
    return(
        class extends React.Component{
            state={authState:false}
        
        render(){
            return(
                <div>
                    {
                        this.state.authState?<Component/>:
                        <h1>Sorry! You are unauthorized</h1>
                    }
                </div>
            )
        }
    }
    )
}

export default HOC