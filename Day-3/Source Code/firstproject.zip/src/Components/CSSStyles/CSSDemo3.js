import React from 'react'
import css from './styles.module.css'

function CSSDemo3() {
  return (
    <div>
        <h1 className={css.success}>Sample Text</h1>
        <h1 className={css.error}>Sample Text</h1>
    </div>
  )
}

export default CSSDemo3