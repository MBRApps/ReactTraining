import React, { Component } from 'react'

export class StateDemo1 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         userid:'Guest'
      }
    }
  changeUserId()
  {
     this.setState({userid:'Admin'})
  }

  render() {
    return (
      <div>
        <h1>UserId:{this.state.userid}</h1>
        <button onClick={()=>this.changeUserId()}>Login</button>
      </div>
    )
  }
}

export default StateDemo1