import React, { useState } from 'react'

function StateDemo3() 
{
    const[count,setCount]=useState(0)
    function increment()
    {
        setCount(count+1)
   }
  return (
    <div>
        Count:{count}
        <button onClick={()=>increment()}>Increment</button>
    </div>
  )
}

export default StateDemo3