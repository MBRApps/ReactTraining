import React, { Component } from 'react'
import ComponentB from './ComponentB'

export class ComponentA extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'John'
      }
      console.log("-----------Parent Constructor---------------")
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log("-----------Parent getDerivedStateFromProps---------------")
        return null;
    }
    componentDidMount()
    {
        console.log("-----------Parent componentDidMount---------------")
    }
   changeState()
   {
        this.setState({name:'Steve Jobs'})
   }
   shouldComponentUpdate()
   {
    console.log("-----------Parent shouldComponentUpdate---------------")
      return true;
   }
   getSnapshotBeforeUpdate(prevProps,prevState)
   {
    //console.log(prevState)
    console.log("-----------Parent getSnapshotBeforeUpdate---------------")
    return null;
   }
   componentDidUpdate()
   {
    console.log("-----------Parent ComponentDidUpdate---------------")
   }

  render() {
    console.log("-----------Parent render---------------")
    return (
      <div>
        <h1>UserName:{this.state.name}</h1>
        <button onClick={()=>this.changeState()}>Change Name</button>
        <ComponentB/>
      </div>
    )
  }
}

export default ComponentA