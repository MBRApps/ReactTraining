import React, { Component } from 'react'

export class FormDemo1 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',email:'',city:''
      }
    }
    changeHandler=(e)=>{
        //console.log(e.target.value)
        this.setState({[e.target.name]:e.target.value})
    }
   
    onsubmitHandler=(e)=>{
        e.preventDefault()
        console.log(this.state)
    }
  render() {
    return (
      <div>
        <form onSubmit={this.onsubmitHandler}>
            <input type="text" placeholder='Enter Name Here' name="name"
             defaultValue={this.state.name} onChange={this.changeHandler}/>
            <br/>
            <input type="text" placeholder='Enter Email' name="email"
            defaultValue={this.state.email} onChange={this.changeHandler}/>
            <br/>
            <select defaultValue={this.state.city} name="city"
             onChange={this.changeHandler}>
                <option value="">--SELECT--</option>
                <option value="abc">ABC</option>
                <option value="xyz">XYZ</option>
            </select>
            <br/>
            <button type='submit'>Submit</button>
        </form>

      </div>
    )
  }
}

export default FormDemo1