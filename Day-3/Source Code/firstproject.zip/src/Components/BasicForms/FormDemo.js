import React, { Component } from 'react'

export class FormDemo extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',email:'',city:''
      }
    }
    changeNameHandler=(e)=>{
        //console.log(e.target.value)
        this.setState({name:e.target.value})
    }
    changeEmailHandler=(e)=>{
        //console.log(e.target.value)
        this.setState({email:e.target.value})
    }
    changeCityHandler=(e)=>{
        //console.log(e.target.value)
        this.setState({city:e.target.value})
    }
    onsubmitHandler=(e)=>{
        e.preventDefault()
        console.log(this.state)
    }
  render() {
    return (
      <div>
        <form onSubmit={this.onsubmitHandler}>
            <input type="text" placeholder='Enter Name Here'
             defaultValue={this.state.name} onChange={this.changeNameHandler}/>
            <br/>
            <input type="text" placeholder='Enter Email' 
            defaultValue={this.state.email} onChange={this.changeEmailHandler}/>
            <br/>
            <select defaultValue={this.state.city} 
             onChange={this.changeCityHandler}>
                <option value="">--SELECT--</option>
                <option value="abc">ABC</option>
                <option value="xyz">XYZ</option>
            </select>
            <br/>
            <button type='submit'>Submit</button>
        </form>

      </div>
    )
  }
}

export default FormDemo