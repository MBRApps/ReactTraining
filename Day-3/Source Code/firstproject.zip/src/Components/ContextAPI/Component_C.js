import React, { Component } from 'react'
import { UserConsumer } from './UserContext'

export class Component_C extends Component {
  render() {
    return (
      <div>
        Component_C
        <UserConsumer>
            {
                (uid)=>{
                    return(
                        <div>
                            <h1>{uid}</h1>
                        </div>
                    )
                }
            }
        </UserConsumer>
      </div>
    )
  }
}

export default Component_C