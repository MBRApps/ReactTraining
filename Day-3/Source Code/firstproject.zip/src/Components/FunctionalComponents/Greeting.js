import React from 'react'

const Greeting=()=> {
  return (
    <div>
        <h1>Good Morning...!</h1>
    </div>
  )
}

export default Greeting