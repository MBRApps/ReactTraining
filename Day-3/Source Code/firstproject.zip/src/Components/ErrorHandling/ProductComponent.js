import React from 'react'

function ProductComponent(props) {
    if(props.children!='Electronics')
    {
        throw new Error('Invalid Category')
    }
  return (
    <div>
        <h1>Product Name:{props.name}</h1>
        <h2>Product Id:{props.id}</h2>
        {props.children}
        <hr/>
    </div>
  )
}

export default ProductComponent