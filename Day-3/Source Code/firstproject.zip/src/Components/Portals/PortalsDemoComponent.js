import React from 'react'
import ReactDOM from 'react-dom'

function PortalsDemoComponent() {
  return ReactDOM.createPortal(
    <div>
        <h1>Welcome User..!</h1>
    </div>,document.getElementById('test')
  )
}

export default PortalsDemoComponent