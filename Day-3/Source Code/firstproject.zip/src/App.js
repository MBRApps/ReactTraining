import logo from './logo.svg';
import './App.css';
import Message from './Components/FunctionalComponents/Message';
import Greeting from './Components/FunctionalComponents/Greeting';
import Welcome from './Components/ClassComponents/Welcome';
import Student from './Components/PropsDemo/Student';
import Employee from './Components/PropsDemo/Employee';
import StateDemo1 from './Components/StateDemo/StateDemo1';
import StateDemo2 from './Components/StateDemo/StateDemo2';
import DSAPDemo1 from './Components/DestructingStateAndProps/DSAPDemo1';
import DSAPDemo2 from './Components/DestructingStateAndProps/DSAPDemo2';
import StateDemo3 from './Components/StateDemo/StateDemo3';
import EventBinding1 from './Components/EventBindings/EventBinding1';
import EventBindings2 from './Components/EventBindings/EventBindings2';
import EventBindings3 from './Components/EventBindings/EventBindings3';
import EventBindings4 from './Components/EventBindings/EventBindings4';
import Parent from './Components/PassingMethodAsProps/Parent';
import CRender1 from './Components/ConditionalRendering/CRender1';
import CRender2 from './Components/ConditionalRendering/CRender2';
import CRender3 from './Components/ConditionalRendering/CRender3';
import CRender4 from './Components/ConditionalRendering/CRender4';
import MapDemo1 from './Components/MapDemo/MapDemo1';
import MapDemo2 from './Components/MapDemo/MapDemo2';
import CSSDemo1 from './Components/CSSStyles/CSSDemo1';
import CSSDemo2 from './Components/CSSStyles/CSSDemo2';
import CSSDemo3 from './Components/CSSStyles/CSSDemo3';
import FormDemo from './Components/BasicForms/FormDemo';
import FormDemo1 from './Components/BasicForms/FormDemo1';
import ComponentA from './Components/LifeCycleHooks/ComponentA';
import Table from './Components/FragmentsDemo/Table';
import RegularComponent from './Components/PureComponentsDemo/RegularComponent';
import PureComponentsDemo from './Components/PureComponentsDemo/PureComponentDemo';
import NormalComponent from './Components/MemoComponents/NormalComponent';
import RefsDemo1 from './Components/RefsInReact/RefsDemo1';
import FRParent from './Components/RefsInReact/FRParent';
import PortalsDemoComponent from './Components/Portals/PortalsDemoComponent';
import ProductComponent from './Components/ErrorHandling/ProductComponent';
import ErrorHandler from './Components/ErrorHandling/ErrorHandler';
import C2P_Parent from './Components/Child2Parent/C2P_Parent';
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './Components/Routing/Home';
import About from './Components/Routing/About';
import Services from './Components/Routing/Services';
import Contact from './Components/Routing/Contact';
import Component_A from './Components/ContextAPI/Component_A';
import { UserProvider } from './Components/ContextAPI/UserContext';
import HOCDemo from './Components/HOCDemo/HOCDemo';

function App() {
  return (
    <div>
         {/* <Message/>
         <Greeting/>
         <Welcome/> */}
         {/* <Student id="1" name="John" age="14"/>
         <Student id="2" name="Steve" age="25"/>

         <Employee id="101" name="Harry" designation="IT-Dev"/>
         <Employee id="102" name="Stefen" designation="IT-Dev"/> */}
         {/* <StateDemo1/> */}
         {/* <StateDemo2/> */}
         {/* <DSAPDemo1 id="1" name="John" age="25" department="Computers"/>
         <DSAPDemo2 id="2" name="Steve" age="26" department="Electronics"/>
         <StateDemo3/> */}
         {/* <EventBinding1/> */}
         {/* <EventBindings2/> */}
         {/* <EventBindings3/> */}
         {/* <EventBindings4/> */}

         {/* <Parent/> */}
         {/* <CRender1/> */}
         {/* <CRender2/> */}
         {/* <CRender3/> */}
         {/* <CRender4/> */}
         {/* <MapDemo1/> */}
         {/* <MapDemo2/> */}
         {/* <CSSDemo1 status={false}/>
         <CSSDemo2/>
         <CSSDemo3/> */}
         {/* <FormDemo/> */}
         {/* <FormDemo1/> */}
         {/* <ComponentA/> */}
         {/* <Table/> */}
         {/* <RegularComponent/>
         <PureComponentsDemo/> */}
         {/* <NormalComponent/> */}
         {/* <RefsDemo1/> */}
         {/* <FRParent/> */}
         {/* <PortalsDemoComponent/> */}
        
        {/* <ErrorHandler>
            <ProductComponent id="1" name="Iphone 15">
                Electronics
            </ProductComponent>
        </ErrorHandler>

        <ErrorHandler>
            <ProductComponent id="2" name="Iphone 15 Pro">
                Electronics
            </ProductComponent>
        </ErrorHandler>

        <ErrorHandler>
            <ProductComponent id="3" name="Audi Q4">
                Automobiles
            </ProductComponent>
        </ErrorHandler>
          */}

          {/* <C2P_Parent/> */}
         {/* <BrowserRouter>
          <Routes>
              <Route path='/' element={<Home/>}></Route>
              <Route path='/about' element={<About/>}></Route>
              <Route path='/services' element={<Services/>}></Route>
              <Route path='/contact' element={<Contact/>}></Route>
          </Routes>
         </BrowserRouter> */}
{/* 
         <UserProvider value={"admin986"}>
              <Component_A/>
         </UserProvider> */}
         
        <HOCDemo/>
    </div>
  );
}

export default App;
