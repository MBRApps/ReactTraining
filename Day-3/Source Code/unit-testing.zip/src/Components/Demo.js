import React,{useState} from 'react'

function Demo(props) {
    const[count,setCount]=useState(0)

    function increment(){
        setCount(count+1)
    }
   return (
    <div>
        <h1>Welcome User</h1>
        <h1>Name:{props.name}</h1>
        <h2>Count:{count}</h2>
        <button onClick={()=>increment()}>Increment</button>
    </div>
  )
}

export default Demo