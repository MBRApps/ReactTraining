import { fireEvent, render, screen } from '@testing-library/react';
import App from './App';
import Demo from './Components/Demo';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

test('Test for msg',()=>{
  render(<Demo/>)
  expect(screen.getByText("Welcome User")).toBeInTheDocument();
})

test('Test for props',()=>{
  render(<Demo name="John"/>)
  expect(screen.getByText("Name:John")).toBeInTheDocument();
})


test('Test for Init Value of Count',()=>{
  render(<Demo/>)
  expect(screen.getByText("Count:0")).toBeInTheDocument();
})

test('Test for Value of Count After Click',()=>{
  render(<Demo/>)
  const btn=screen.getByRole('button')
  fireEvent.click(btn)
  expect(screen.getByText("Count:1")).toBeInTheDocument();
})