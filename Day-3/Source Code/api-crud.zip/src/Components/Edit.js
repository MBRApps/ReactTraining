import axios from 'axios'
import React, { Component } from 'react'

export class Edit extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       id:0,first_name:'',last_name:'',email:''
    }
  }
  componentDidMount()
  {
    const _id=window.location.pathname.split('/')[2]
    // fetch('http://localhost:3200/posts/'+_id,{method:'GET'})
    // .then(result=>{return result.json()})
    // .then(res=>{
    //   console.log(res)
    //   this.setState({
    //     id:res['id'],first_name:res['first_name'],last_name:res['last_name'],
    //     email:res['email']
    //   })
    // })
    axios.get('/posts/'+_id)
    .then(res=>{
      this.setState({
        id:res.data['id'],first_name:res.data['first_name'],last_name:res.data['last_name'],
       email:res.data['email']
      })
    })
  }
  changeHandler=(e)=>{
    this.setState({
      [e.target.name]:e.target.value
    })
  }
  submitHandler=(e)=>{
    e.preventDefault();
    console.log(this.state)
    // fetch('http://localhost:3200/posts/'+this.state.id,{
    //   method:'PUT',
    //   headers:{Accept:'application/json','Content-Type':'application/json'},
    //   body:JSON.stringify(this.state)
    // }).then(res=>{
    //   if(res.status==200)
    //   {
    //     alert('User Details Updated Successfully')
    //     window.location='../'
    //   }
    // })
    axios.put('/posts/'+this.state.id,this.state)
    .then(res=>{
      if(res.status==200)
      {
      alert('User Details Updated Successfully')
      window.location='../'
       }
    })
  }
  render() {
    return (
      <div className='container mt-5'>
          <div className='container mt-3 alert alert-success'>
            <h1>Edit User</h1>
          </div>
          <form onSubmit={this.submitHandler}>
            <div className='row'>
                <div className='col'>
                  <input type="text" name="first_name" className='form-control' 
                  placeholder='Enter First Name' defaultValue={this.state.first_name} onChange={this.changeHandler}/>
                </div>
                <div className='col'>
                  <input type="text" name="last_name" className='form-control' 
                  placeholder='Enter Last Name' defaultValue={this.state.last_name} onChange={this.changeHandler}/>
                </div>
            </div>
            <div className='row mt-3'>
                <div className='col'>
                  <input type="text" name="email" className='form-control' 
                  placeholder='Enter E-Mail' defaultValue={this.state.email} onChange={this.changeHandler}/>
                </div>                
            </div>
            <div className='row mt-3'>
                <div className='col'>
                  <input type="submit" className='btn btn-success'/>
                </div>                
            </div>
          </form>
      </div>
    )
  }
}

export default Edit