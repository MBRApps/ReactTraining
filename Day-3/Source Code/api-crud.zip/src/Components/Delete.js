import axios from 'axios'
import React,{useEffect} from 'react'
import {useParams} from 'react-router-dom'

function Delete() 
{
  const{id}=useParams()
  useEffect(()=>{
    // fetch('http://localhost:3200/posts/'+id,{
    //   method:'DELETE',
    //   headers:{Accept:'application/json','Content-Type':'application/json'}
    // }).then(res=>{
    //   if(res.status==200)
    //   {
    //     alert('Record Deleted Successfully')
    //     window.location='../'
    //   }
    // })
    axios.delete('/posts/'+id)
    .then(res=>{
      if(res.status==200)
        {
          alert('Record Deleted Successfully')
          window.location='../'
        }
    })
  },[])
  return (
    <div>Delete</div>
  )
}

export default Delete