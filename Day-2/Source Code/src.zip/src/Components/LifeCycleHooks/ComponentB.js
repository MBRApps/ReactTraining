import React, { Component } from 'react'

export class ComponentB extends Component {
    constructor(props) {
      super(props)
       this.state={name:''}
     
      console.log("-----------Child Constructor---------------")
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log("-----------Child getDerivedStateFromProps---------------")
        return null;
    }
    componentDidMount()
    {
        console.log("-----------Child componentDidMount---------------")
    }

    
  render() {
    console.log("-----------Child render---------------")
    return (
      <div>
        <h1>Child Component</h1>
      </div>
    )
  }
}

export default ComponentB