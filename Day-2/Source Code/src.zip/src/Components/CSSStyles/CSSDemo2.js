import React from 'react'

const mystyles={
    color:'orange',fontSize:'45px'
}
function CSSDemo2() {
  return (
    <div style={mystyles}>CSSDemo2</div>
  )
}

export default CSSDemo2