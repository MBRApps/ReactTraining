import React from 'react'
import './mystyles.css'

function CSSDemo1(props) {
    const colorClass=props.status?'online':'offline'
  return (
    <div>
        <h1 className={colorClass}>Sample Text Here</h1>
    </div>
  )
}

export default CSSDemo1