import React from 'react'

function TableBody() {
  return (
    <React.Fragment>
        <tbody>
            <tr>
                <td>1</td>
                <td>C++</td>
            </tr>
            <tr>
                <td>2</td>
                <td>C#.NET</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Angular</td>
            </tr>
        </tbody>
    </React.Fragment>
  )
}

export default TableBody