import React, { Component } from 'react'

export class RegularComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'steve'
      }
    }
    componentDidMount()
    {
        setInterval(()=>{
            this.setState({name:'steve'})
        },2000)
    }
  render() {
    console.log("------------Regular Component-------------------")
    return (
      <div>RegularComponent</div>
    )
  }
}

export default RegularComponent