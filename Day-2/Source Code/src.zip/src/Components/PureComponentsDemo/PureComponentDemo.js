import React, { Component, PureComponent } from 'react'

export class PureComponentsDemo extends PureComponent{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'steve'
      }
    }
    componentDidMount()
    {
        setInterval(()=>{
            this.setState({name:'steve'})
        },2000)
    }
  render() {
    console.log("------------Pure Component-------------------")
    return (
      <div>Pure Component</div>
    )
  }
}

export default PureComponentsDemo