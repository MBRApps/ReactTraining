import React, { Component } from 'react'

export class RefsDemo1 extends Component 
{
    constructor(props) {
      super(props)
       this.nameref=React.createRef()     
    }
    componentDidMount()
    {
        this.nameref.current.placeholder="Enter Name Here"
        this.nameref.current.focus()
    }
    clickHandler=()=>{
        alert(this.nameref.current.value)
    }
  render() {
    return (
      <div>
        <input ref={this.nameref}/>
        <button onClick={this.clickHandler}>Click Me</button>
      </div>
    )
  }
}

export default RefsDemo1