import React, { Component } from 'react'
import Component_B from './Component_B'

export class Component_A extends Component {
  render() {
    return (
      <div>
        Component_A
        <Component_B/>
      </div>
    )
  }
}

export default Component_A