import React, { Component } from 'react'
import Component_C from './Component_C'

export class Component_B extends Component {
  render() {
    return (
      <div>
        Component_B
        <Component_C/>
     </div>
    )
  }
}

export default Component_B