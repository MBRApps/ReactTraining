import React from 'react'
import C2P_Child from './C2P_Child'

function callback(msg)
{
    return(
        <h1>Message From Child:{msg}</h1>
    )
}
function C2P_Parent() {
  return (
    <div>
        <C2P_Child handler={callback}/>
    </div>
  )
}

export default C2P_Parent