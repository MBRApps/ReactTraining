import React from 'react'

function C2P_Child(props) {
  return (
    <div>
        {props.handler('Hello Parent!')}
    </div>
  )
}

export default C2P_Child