import React from 'react'

function Message() {
  return (
    <div>
        <h1>Hello User</h1>
        <h2>Good Morning...</h2>
    </div>
  )
}

export default Message