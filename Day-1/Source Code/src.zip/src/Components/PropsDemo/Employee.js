import React, { Component } from 'react'

export class Employee extends Component {
  render() {
    return (
      <div>
        <h1>Name:{this.props.name}</h1>
        <h2>Designation:{this.props.designation}</h2>
      </div>
    )
  }
}

export default Employee