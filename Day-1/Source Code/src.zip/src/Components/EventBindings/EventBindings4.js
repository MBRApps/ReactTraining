import React, { Component } from 'react'

class EventBindings4 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Guest'
      }
    }
    changeName()
    {
        this.setState({name:'Admin'})
    }
  render() {
    return (
      <div>
            <h1>{this.state.name}</h1>
            <br/>
            <button onClick={()=>this.changeName()}>Click Me</button>
      </div>
    )
  }
}

export default EventBindings4