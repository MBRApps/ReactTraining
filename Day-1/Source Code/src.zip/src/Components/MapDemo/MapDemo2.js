import React from 'react'

function MapDemo2() {
    const courses=[
        {id:101,title:'C#',duration:30},
        {id:102,title:'C++',duration:15},
        {id:103,title:'Angular',duration:25},
        {id:104,title:'React',duration:25},
        {id:105,title:'SQL',duration:15}
    ]
  return (
    <div>
        <table className='table table-responsive table-bordered table-hover'>
            <thead>
                <tr className='table-primary'>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Duration</th>
                </tr>
            </thead>
            <tbody>
                {
                    courses.map((course,i)=>
                    <tr key={i}>
                        <td>{course.id}</td>
                        <td>{course.title}</td>
                        <td>{course.duration}</td>
                    </tr>)
                }
            </tbody>
        </table>
    </div>
  )
}

export default MapDemo2