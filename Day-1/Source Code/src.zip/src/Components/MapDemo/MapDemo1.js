import React from 'react'

function MapDemo1() {
    const courses=['c','c++','java','C#.NET']
  return (
    <div>
        <ol>
            {
                courses.map((course,index)=>
                    <li key={index}>{course}</li>)
            }
        </ol>
    </div>
  )
}
export default MapDemo1