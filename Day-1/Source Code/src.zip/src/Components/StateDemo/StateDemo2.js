import React, { Component } from 'react'

export class StateDemo2 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         counter:0
      }
    }
 increment()
 {
    this.setState({counter:this.state.counter+1},()=>{
        console.log(this.state.counter)
    })
    
 }

  render() {
    return (
      <div>
        Count:{this.state.counter}
        <br/>
        <button onClick={()=>this.increment()}>Increment</button>
      </div>
    )
  }
}

export default StateDemo2